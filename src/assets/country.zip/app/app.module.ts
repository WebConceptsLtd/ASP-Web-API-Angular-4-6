import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { RouterModule } from "@angular/router";
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { CountriesComponent } from './countries/countries.component';
import { AjaxService } from './shared/services/ajax.service';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';



@NgModule({
    imports: [
        HttpClientModule,
        BrowserModule,
        FormsModule,
        RouterModule, // Need this module for the routing
        AppRoutingModule // Import app routing module
    ],
    declarations: [
        AppComponent,
        HeaderComponent,
        HomeComponent,
        CountriesComponent
      
    ],
    providers: [ // Services עבור הגדרות
     AjaxService
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
