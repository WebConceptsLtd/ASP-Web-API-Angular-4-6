export class Countries {
  name: string;
  nativeName: string;
  capital: string;
  population: number;
  flag: string;
}