import { Injectable } from '@angular/core';
import { Countries } from '../shared/module/conrie';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AjaxService {
  
  constructor(private ajaxParamService: HttpClient) { }
  
  getCountries(myfunc: (countries: Array<Countries>) => void): void { 
    this.ajaxParamService.get("https://restcountries.eu/rest/v2/all").
    subscribe(myfunc);
  }
}