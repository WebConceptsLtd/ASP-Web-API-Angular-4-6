import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { CountriesComponent } from './countries/countries.component';

// הנתיבים השונים שקיימים באתר
const appRoutes: Routes = [
    { path: "home", component: HomeComponent },
    { path: "countries", component: CountriesComponent },
    { path: "", redirectTo: "/home", pathMatch: "full" }
];

// אובייקט ראוטר - יודע איך להחליף את הקומפוננטות לפי הנתיבים
const appRouter = RouterModule.forRoot(appRoutes);

@NgModule({
    imports: [appRouter]
})
export class AppRoutingModule {}




