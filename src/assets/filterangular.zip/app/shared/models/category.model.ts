export class Category {
    
    constructor(public categoryID: number,
                public categoryName: string) { }
}