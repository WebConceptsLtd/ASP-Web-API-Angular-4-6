import { Component, OnInit } from '@angular/core';
import { AjaxService } from '../shared/services/ajax.service';
import { RootObject } from '../shared/models/aboutinfo.model';

@Component({
    selector: 'jb-aboutus',
    templateUrl: './aboutus.component.html',
    styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

   
    constructor(private ajaxService: AjaxService) { }

      responseParam: RootObject = new RootObject();
      funcPram:(y:RootObject)=>void;
    
      ngOnInit(){
           this.funcPram=(x:RootObject):void => {this.responseParam=x};
            this.ajaxService.getPerson(this.funcPram);
      }

 

  
  
}

