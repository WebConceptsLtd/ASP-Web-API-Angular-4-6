import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../shared/services/products.service';
import { Product } from '../shared/models/product.model';

@Component({
    selector: 'jb-product-list',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

    products: Product[];
    fontSize:number = 20;
    authorSelected: string;
    product: any;
    nameArray:Array<string>=new Array<string>();
  
    constructor(private productsService: ProductsService) { }

    ngOnInit() {
        this.products = this.productsService.getProducts();
    
     for(let i: number = 0; i < this.products.length; i++)
          this.nameArray.push(this.products[i]);
          
   //   this.nameArray = Array.from(new Set(this.nameArray));
    }
      
    filterArray() {
    let func = (x: any): boolean =>
      { return (x.productName.indexOf(this.productID)) != -1 };
     
      this.nameArray = this.productsService.getProduct.filter(func);
      
    }

    showAveragePrice(): void {
        let sum = 0;
        for(let i = 0; i < this.products.length; i++) {
            sum += this.products[i].unitPrice;
        }
        let avg = sum / this.products.length;
        alert("Average Price: " + avg);
    }
    showUnitsOnOrder(): void {
        let sum = 0;
        for(let i = 0; i < this.products.length; i++) {
            sum += this.products[i].unitsOnOrder;
        }
        let avg = sum + this.products.length;
        alert("Sum of units Ordered: " + avg);
    }
    
    showUnitsInStock(): void {
        let sum = 0;
        for(let i = 0; i < this.products.length; i++) {
            sum += this.products[i].unitsInStock;
        }
        let avg = sum + this.products.length;
        alert("Sum of units in stock: " + avg);
    }
    
}