
export class ProductCategory {
    productCategoryId: number
    productCategoryName: string
    active: boolean

}