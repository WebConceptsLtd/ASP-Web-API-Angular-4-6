export class Product {
    productId: number
    productName: string
    price: number
    imagePath: string
    description: string
    status: boolean
    productCategoryId: number    
    extract:string

}