import { Component } from '@angular/core';
import { ProductListComponent } from './product-list.component'

@Component({
  selector: 'my-home',
  templateUrl: './product-home.html'

})

export class ProductHomeComponent {

}