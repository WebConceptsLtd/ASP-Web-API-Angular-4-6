export * from './home.component'
export * from './home.module'
export * from './about.component'
export * from './index.component'


