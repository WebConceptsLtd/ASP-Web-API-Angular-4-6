import { Component } from '@angular/core';

@Component({
  selector: 'home-page',
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class HomeComponent {
  constructor() {}

}