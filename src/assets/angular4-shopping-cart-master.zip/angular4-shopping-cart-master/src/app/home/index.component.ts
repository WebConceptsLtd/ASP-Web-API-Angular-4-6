import { Component } from '@angular/core';

@Component({
  selector: 'index',
  templateUrl: './index.html' 
})
export class IndexComponent {
  constructor() {}

}