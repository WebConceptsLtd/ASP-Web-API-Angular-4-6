export interface CartCount {
    counter: number
}